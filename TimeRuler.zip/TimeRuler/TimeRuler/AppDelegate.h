//
//  AppDelegate.h
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

