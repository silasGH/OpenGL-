//
//  SGRulerView.m
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#define kFontSize 8  // 时间字体大小

#import "SGRulerView.h"

@implementation SGRulerView

- (void)drawRect:(CGRect)rect {
    // 获取到当前上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 设置线宽
    CGContextSetLineWidth(context, 0.5);
    
    //1.画底线
    CGFloat start_x = 0;
    CGFloat start_y = rect.size.height / 2;
    CGFloat end_x = rect.size.width;
    CGFloat end_y = start_y;
    CGContextSetStrokeColorWithColor(context, [UIColor orangeColor].CGColor);
    
    CGContextMoveToPoint(context, start_x, start_y);
    CGContextAddLineToPoint(context, end_x, end_y);
    CGContextStrokePath(context);
    
    //2.画刻度
    //2.1时间起始刻度(00:00:00)
    CGContextSetStrokeColorWithColor(context, [UIColor orangeColor].CGColor);
    CGContextMoveToPoint(context, self.timeLineOffset - self.offsetH, start_y);
    CGContextAddLineToPoint(context,self.timeLineOffset - self.offsetH, start_y-10);
    CGContextStrokePath(context);
    

    NSInteger timeCount = self.rulerModel.timeCount;
    for (NSInteger i = 1; i <= timeCount; i++) {
        CGContextSetStrokeColorWithColor(context, [UIColor orangeColor].CGColor);
        
        CGContextMoveToPoint(context, (i * self.rulerModel.hGap) + self.timeLineOffset - self.offsetH, start_y);
        CGContextAddLineToPoint(context, (i * self.rulerModel.hGap) + self.timeLineOffset - self.offsetH, start_y-10);
        CGContextStrokePath(context);
    }
    
    //2.3绘制时间文本
    NSDictionary *attributes = @{NSForegroundColorAttributeName:[UIColor orangeColor],
                                 NSFontAttributeName:[UIFont systemFontOfSize:kFontSize]};
    NSString *firstTime = [self.rulerModel timeTextWithTimeGap:self.rulerModel.timeGap index:0];
    CGRect textRect = [firstTime boundingRectWithSize:CGSizeMake(100, 50) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil];
    
    for (NSInteger i = 0; i <= self.rulerModel.timeCount; i++) {
        NSString *timeText = [self.rulerModel timeTextWithTimeGap:self.rulerModel.timeGap index:i];
        CGPoint textPoint = CGPointMake((i * self.rulerModel.hGap) + self.timeLineOffset - (textRect.size.width / 2) - self.offsetH, start_y + 5);
        
        if (self.rulerModel.timeGap == SGRulerTimeGapTwoHour) {
            [timeText drawAtPoint:textPoint withAttributes:attributes];
        } else if (self.rulerModel.timeGap == SGRulerTimeGapHour) {
            if (self.rulerModel.hGap >= (self.rulerModel.defaultHGap * 2)) {
                [timeText drawAtPoint:textPoint withAttributes:attributes];
            } else {
                if ((i % 2) == 0) {
                    [timeText drawAtPoint:textPoint withAttributes:attributes];
                }
            }
        } else if (self.rulerModel.timeGap == SGRulerTimeGapHalfHour) {
            [timeText drawAtPoint:textPoint withAttributes:attributes];
        } else if (self.rulerModel.timeGap == SGRulerTimeGapTenMinute) {
            [timeText drawAtPoint:textPoint withAttributes:attributes];
        } else if (self.rulerModel.timeGap == SGRulerTimeGapFiveMinute) {
            [timeText drawAtPoint:textPoint withAttributes:attributes];
        } else if (self.rulerModel.timeGap == SGRulerTimeGapOneMinute) {
            if (self.rulerModel.hGap >= (self.rulerModel.defaultHGap * 2)) {
                [timeText drawAtPoint:textPoint withAttributes:attributes];
            } else {
                if ((i % 2) == 0) {
                    [timeText drawAtPoint:textPoint withAttributes:attributes];
                }
            }
        }
    }
}

@end
