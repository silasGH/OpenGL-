//
//  NSObject+DS.m
//  DSDemos
//
//  Created by 宋利军 on 16/2/3.
//  Copyright © 2016年 Derek. All rights reserved.
//

#import "NSObject+DS.h"

@implementation NSObject (DS)

+ (NSInteger)secondWithTimeStr:(NSString *)timeStr {
    NSString *str = @"\\d{1,2}.\\d{1,2}.\\d{1,2}";
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",str];
    
    if ([pre evaluateWithObject:timeStr]) {
        NSArray *arr = [timeStr componentsSeparatedByString:@":"];
        NSInteger second = [arr[0] integerValue] * 60 * 60 + [arr[1] integerValue] * 60 + [arr[2] integerValue];
        return second;
    } else {
        NSLog(@"timeStr == %@,不符合HH:mm:ss的时间格式", timeStr);
        return 0;
    }
}

+ (CGFloat)scaleFor24HourOfTimeStr:(NSString *)timeStr {
    NSInteger second = [self secondWithTimeStr:timeStr];
    return second / (60 * 60 * 24.0);
}

@end
