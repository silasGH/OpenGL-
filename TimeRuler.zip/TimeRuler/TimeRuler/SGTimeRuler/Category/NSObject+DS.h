//
//  NSObject+DS.h
//  DSDemos
//
//  Created by 宋利军 on 16/2/3.
//  Copyright © 2016年 Derek. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSObject (DS)

/** 将"HH:mm:ss"格式的时间字符串换算成等量的秒数 */
+ (NSInteger)secondWithTimeStr:(NSString *)timeStr;

/** 计算"HH:mm:ss"格式的时间字符串换算成等量的秒数后在24小时的秒数下所占的比例 */
+ (CGFloat)scaleFor24HourOfTimeStr:(NSString *)timeStr;

@end
