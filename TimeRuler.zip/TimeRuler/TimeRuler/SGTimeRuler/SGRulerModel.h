//
//  SGRulerModel.h
//  RulerDemo
//
//  Created by iBahs on 17/3/17.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    SGRulerTimeGapUnknow,
    SGRulerTimeGapTwoHour = 7200,
    SGRulerTimeGapHour = 3600,
    SGRulerTimeGapHalfHour = 1800,
    SGRulerTimeGapTenMinute = 600,
    SGRulerTimeGapFiveMinute = 300,
    SGRulerTimeGapOneMinute = 60,
    SGRulerTimeGapDefault = SGRulerTimeGapTwoHour
} SGRulerTimeGap;

@interface SGRulerModel : NSObject

/** 每个刻度间距所代表的时间间隔(单位:秒) */
@property (nonatomic, assign) SGRulerTimeGap timeGap;
/** 刻度之间的水平间距 */
@property (nonatomic, assign) CGFloat hGap;
/** 时间刻度数量(不计算起始刻度) */
@property (nonatomic, assign) NSInteger timeCount;
@property (nonatomic, assign) CGFloat contentWidth;
@property (nonatomic, assign) CGFloat defaultHGap;

- (instancetype)initWithDefaultGap:(CGFloat)defaultGap;

/**
 根据当前刻度的时间间隔和下标计算该刻度下的时间文本

 @param timeGap 刻度的时间间隔
 @param index   下标

 @return 该刻度下的时间文本
 */
- (NSString *)timeTextWithTimeGap:(SGRulerTimeGap)timeGap
                            index:(NSInteger)index;

@end
