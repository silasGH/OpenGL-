//
//  SGRulerView.h
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SGRulerModel.h"

@interface SGRulerView : UIView

@property (nonatomic, assign) CGFloat timeLineOffset;//时间轴起始位置偏移
@property (nonatomic, assign) CGFloat offsetH;//水平方向的偏移量
@property (nonatomic, strong) SGRulerModel *rulerModel;

@end
