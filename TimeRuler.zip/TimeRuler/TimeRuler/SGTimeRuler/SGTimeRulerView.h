//
//  SGTimeRulerView.h
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGTimeRulerView : UIView

- (void)setupTime:(NSString *)time;
- (void)resetOffsetX:(CGFloat)x;
@end
