//
//  SGTimeRulerView.m
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import "SGTimeRulerView.h"
#import "NSObject+DS.h"
#import "SGRulerView.h"

@interface SGTimeRulerView ()<UIScrollViewDelegate>

@property (nonatomic, weak) UIScrollView *scrollView;
@property (nonatomic, weak) SGRulerView *rulerView;
@property (nonatomic, weak) UIView *redLine;
@property (nonatomic, weak) UILabel *timeLab;
@property (nonatomic, weak) UIPinchGestureRecognizer *recognizer;
@property (nonatomic, assign) CGFloat beganGap;
@property (nonatomic, assign) CGFloat beganProgress;
@property (nonatomic, assign) CGFloat offsetX;
@property (nonatomic, assign) BOOL usableMyOffsetX;

@end

@implementation SGTimeRulerView

- (void)dealloc {
    [self.rulerView.rulerModel removeObserver:self forKeyPath:@"hGap"];
    [self.rulerView.rulerModel removeObserver:self forKeyPath:@"timeGap"];
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupSubviews];
    }
    return self;
}

- (void)setupSubviews {
    [self rulerView];
    [self redLine];
    [self timeLab];
}

- (void)setupTime:(NSString *)time {
//    NSInteger inputSecond = [NSObject secondWithTimeStr:time];
//    NSInteger labSecond = [NSObject secondWithTimeStr:self.timeLab.text];

    CGFloat progress = [NSObject scaleFor24HourOfTimeStr:time];
    CGFloat realTotalW = self.scrollView.contentSize.width - (self.rulerView.timeLineOffset * 2);

    self.offsetX = realTotalW * progress;
    self.scrollView.contentOffset = CGPointMake(self.offsetX, self.scrollView.contentOffset.y);

    self.usableMyOffsetX = YES;
    [self scrollViewDidScroll:self.scrollView];
}

- (void)setupScrollViewContentOffsetWtihScale:(CGFloat)scale {}

- (void)pinchAction:(UIPinchGestureRecognizer *)pinch {
    self.recognizer = pinch;
    CGFloat realTotalW = self.scrollView.contentSize.width - (self.rulerView.timeLineOffset * 2);
    
    if (pinch.state == UIGestureRecognizerStateBegan) {
        self.beganGap = self.rulerView.rulerModel.hGap;
        self.beganProgress = self.scrollView.contentOffset.x / realTotalW;
    } else if (pinch.state == UIGestureRecognizerStateEnded) {
        self.timeLab.text = [self timeFor24HourWtihScrollView:self.scrollView];
    }
    //    NSLog(@"---pinch.scale---%f", pinch.scale);
    self.rulerView.rulerModel.hGap = self.beganGap * pinch.scale;
    self.scrollView.contentOffset = CGPointMake(realTotalW * self.beganProgress, self.scrollView.contentOffset.y);
    //重绘刻度尺
    [self.rulerView setNeedsDisplay];
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if ([keyPath isEqualToString:@"hGap"]) {
        SGRulerModel *model = self.rulerView.rulerModel;
        CGFloat totalGap = model.timeCount * model.hGap;
        self.scrollView.contentSize = CGSizeMake(totalGap + self.scrollView.bounds.size.width, self.scrollView.bounds.size.height);
//        self.rulerView.frame = CGRectMake(0, 0, self.scrollView.contentSize.width, self.scrollView.contentSize.height);
    } else if ([keyPath isEqualToString:@"timeGap"]) {
        self.recognizer.scale = 1;
        self.beganGap = self.rulerView.rulerModel.hGap;
    }
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat realOffsetX = self.usableMyOffsetX ? self.offsetX : scrollView.contentOffset.x;

    self.rulerView.frame = CGRectMake(realOffsetX, 0, scrollView.bounds.size.width, scrollView.bounds.size.height);
    
    self.rulerView.offsetH = realOffsetX;
    [self.rulerView setNeedsDisplay];
    
    self.timeLab.text = [self timeFor24HourWtihScrollView:scrollView];
}

- (NSString *)timeFor24HourWtihScrollView:(UIScrollView *)scrollView {
    CGFloat realTotalW = scrollView.contentSize.width - (self.rulerView.timeLineOffset * 2);
    CGFloat offsetX = self.usableMyOffsetX ? self.offsetX : scrollView.contentOffset.x;
    CGFloat progress = offsetX / realTotalW;
    self.usableMyOffsetX = NO;

    CGFloat secondTemp = progress * (60 * 60 * 24);
    NSString *secondStr = [NSString stringWithFormat:@"%.f", secondTemp];
    NSInteger second = secondStr.integerValue;

    NSInteger hour = second / (60 * 60);
    NSInteger minute = (second % 3600) / 60;
    NSInteger ss = second % 60;
    NSString *time = [NSString stringWithFormat:@"%.2ld:%.2ld:%.2ld", hour, minute, ss];
//    NSLog(@"%ld, minute = %ld, ss == %ld, progress = %f", hour, minute, ss, progress);
    return time;
}
- (void)resetOffsetX:(CGFloat)x {
    self.scrollView.contentOffset = CGPointMake(x, self.scrollView.contentOffset.y);
}
#pragma mark - setter and getter
- (UIScrollView *)scrollView {
    if (_scrollView == nil) {
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        scrollView.contentSize = CGSizeMake(self.bounds.size.width * 2, self.bounds.size.height);
        scrollView.delegate = self;
        scrollView.bounces = NO;
        scrollView.decelerationRate = -1;
        
        UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAction:)];
        [scrollView addGestureRecognizer:pinch];
        
        [self addSubview:scrollView];
        _scrollView = scrollView;
    }
    return _scrollView;
}

- (SGRulerView *)rulerView {
    if (_rulerView == nil) {
        SGRulerView *rulerView = [[SGRulerView alloc] initWithFrame:self.scrollView.bounds];
        rulerView.timeLineOffset = self.scrollView.bounds.size.width / 2;
        rulerView.backgroundColor = [UIColor colorWithRed:231/255.0 green:250/255.0 blue:255/255.0 alpha:1.0];
        
        SGRulerModel *rulerModel = [[SGRulerModel alloc] initWithDefaultGap:self.scrollView.bounds.size.width / 12];
        [rulerModel addObserver:self forKeyPath:@"hGap" options:0 context:nil];
        [rulerModel addObserver:self forKeyPath:@"timeGap" options:0 context:nil];
        rulerView.rulerModel = rulerModel;
        
        [self.scrollView addSubview:rulerView];
        _rulerView = rulerView;
    }
    return _rulerView;
}

- (UIView *)redLine {
    if (_redLine == nil) {
        CGFloat h = self.bounds.size.height;
        CGFloat w = 0.5;
        CGFloat x = (self.bounds.size.width - w) / 2;
        UIView *redLine = [[UIView alloc] initWithFrame:CGRectMake(x, 0, w, h)];
        redLine.backgroundColor = [UIColor redColor];
        [self addSubview:redLine];
        _redLine = redLine;
    }
    return _redLine;
}

- (UILabel *)timeLab {
    if (_timeLab == nil) {
        UILabel *timeLab = [[UILabel alloc] initWithFrame:CGRectMake((self.bounds.size.width / 2 + 10.0), 5.0, self.bounds.size.width / 2 - 10.0, 20.0)];
        timeLab.textAlignment = NSTextAlignmentLeft;
        timeLab.text = @"00:00:00";
        [self addSubview:timeLab];
        _timeLab = timeLab;
    }
    return _timeLab;
}

@end
