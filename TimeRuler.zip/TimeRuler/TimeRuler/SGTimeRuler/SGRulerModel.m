//
//  SGRulerModel.m
//  RulerDemo
//
//  Created by iBahs on 17/3/17.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import "SGRulerModel.h"

@interface SGRulerModel ()



@end

@implementation SGRulerModel

- (instancetype)initWithDefaultGap:(CGFloat)defaultGap {
    if (self = [super init]) {
        self.timeGap = SGRulerTimeGapDefault;
        self.defaultHGap = defaultGap;
        self.hGap = defaultGap;
    }
    return self;
}

/**
 根据当前刻度的时间间隔和下标计算该刻度下的时间文本
 
 @param timeGap 刻度的时间间隔
 @param index   下标
 
 @return 该刻度下的时间文本
 */
- (NSString *)timeTextWithTimeGap:(SGRulerTimeGap)timeGap
                            index:(NSInteger)index {
    NSUInteger secondGap = (NSUInteger)self.timeGap;
    NSInteger resultSecond = secondGap * index;
    switch (self.timeGap) {
        case SGRulerTimeGapTwoHour:
        {
            NSInteger resultHour = resultSecond / 60 / 60;
            return [NSString stringWithFormat:@"%.2ld", resultHour];
        }
            break;
        case SGRulerTimeGapHour:
        {
            NSInteger resultHour = resultSecond / 60 / 60;
            return [NSString stringWithFormat:@"%.2ld:00", resultHour];
        }
            break;
        case SGRulerTimeGapHalfHour:
        {
            NSInteger shangShu = resultSecond / 1800;
            if (shangShu == 0) {
                return @"00:00";
            }
            if ((shangShu % 2) > 0) {//奇数
                return [NSString stringWithFormat:@"%.2ld:30", (shangShu - 1) / 2];
            } else {//偶数(整点小时)
                return [NSString stringWithFormat:@"%.2ld:00", shangShu / 2];
            }
        }
            break;
        case SGRulerTimeGapTenMinute:
        {
            NSInteger shangShu = resultSecond / 600;
            NSInteger hour = shangShu / 6;
            NSInteger minute = (shangShu % 6) * 10;
            if (minute == 0) {
                return [NSString stringWithFormat:@"%.2ld:00", hour];
            } else {
                return [NSString stringWithFormat:@"%.2ld:%ld", hour, minute];
            }
        }
            break;
        case SGRulerTimeGapFiveMinute:
        {
            NSInteger shangShu = resultSecond / 300;
            NSInteger hour = shangShu / 12;
            NSInteger minute = (shangShu % 12) * 5;
            if (minute == 0) {
                return [NSString stringWithFormat:@"%.2ld:00", hour];
            } else {
                return [NSString stringWithFormat:@"%.2ld:%.2ld", hour, minute];
            }
        }
            break;
        case SGRulerTimeGapOneMinute:
        {
            NSInteger shangShu = resultSecond / 60;
            NSInteger hour = shangShu / 60;
            NSInteger minute = (shangShu % 60);
            if (minute == 0) {
                return [NSString stringWithFormat:@"%.2ld:00", hour];
            } else {
                return [NSString stringWithFormat:@"%.2ld:%.2ld", hour, minute];
            }
        }
            break;
        default:
            break;
    }
    return nil;
}

#pragma mark - setter and getter
- (void)setHGap:(CGFloat)hGap {
    if (hGap > _hGap) {//放大
        _hGap = hGap;
        
        switch (self.timeGap) {
            case SGRulerTimeGapTwoHour:
            {
                if (hGap >= (self.defaultHGap * 2)) {
                    _hGap = self.defaultHGap;
                    self.timeGap = SGRulerTimeGapHour;
                }
            }
                break;
            case SGRulerTimeGapHour:
            {
                if (hGap >= (self.defaultHGap * 6)) {
                    _hGap = self.defaultHGap * 3;
                    self.timeGap = SGRulerTimeGapHalfHour;
                }
            }
                break;
            case SGRulerTimeGapHalfHour:
            {
                if (hGap >= (self.defaultHGap * 6)) {
                    _hGap = self.defaultHGap * 2;
                    self.timeGap = SGRulerTimeGapTenMinute;
                }
            }
                break;
            case SGRulerTimeGapTenMinute:
            {
                if (hGap >= (self.defaultHGap * 4)) {
                    _hGap = self.defaultHGap * 2;
                    self.timeGap = SGRulerTimeGapFiveMinute;
                }
            }
                break;
            case SGRulerTimeGapFiveMinute:
            {
                if (hGap >= (self.defaultHGap * 5)) {
                    _hGap = self.defaultHGap;
                    self.timeGap = SGRulerTimeGapOneMinute;
                }
            }
                break;
            case SGRulerTimeGapOneMinute:
            {
                if (hGap >= (self.defaultHGap * 5)) {
                    _hGap = (self.defaultHGap * 5);
                    self.timeGap = SGRulerTimeGapOneMinute;
                }
            }
                break;
            default:
                break;
        }
        
    } else if (hGap < _hGap) {//缩小
        _hGap = hGap;
        
        switch (self.timeGap) {
            case SGRulerTimeGapOneMinute:
            {
                if (hGap <= self.defaultHGap) {
                    _hGap = self.defaultHGap * 5;
                    self.timeGap = SGRulerTimeGapFiveMinute;
                }
            }
                break;
            case SGRulerTimeGapFiveMinute:
            {
                if (hGap <= self.defaultHGap * 2) {
                    _hGap = self.defaultHGap * 4;
                    self.timeGap = SGRulerTimeGapTenMinute;
                }
            }
                break;
            case SGRulerTimeGapTenMinute:
            {
                if (hGap <= self.defaultHGap * 2) {
                    _hGap = self.defaultHGap * 6;
                    self.timeGap = SGRulerTimeGapHalfHour;
                }
            }
                break;
            case SGRulerTimeGapHalfHour:
            {
                if (hGap <= self.defaultHGap * 3) {
                    _hGap = self.defaultHGap * 6;
                    self.timeGap = SGRulerTimeGapHour;
                }
            }
                break;
            case SGRulerTimeGapHour:
            {
                if (hGap <= self.defaultHGap) {
                    _hGap = self.defaultHGap * 2;
                    self.timeGap = SGRulerTimeGapTwoHour;
                }
            }
                break;
            case SGRulerTimeGapTwoHour:
            {
                if (hGap <= self.defaultHGap) {
                    _hGap = self.defaultHGap;
                    self.timeGap = SGRulerTimeGapTwoHour;
                }
            }
                break;
            default:
                break;
        }

    }
    
    
}

- (void)setTimeGap:(SGRulerTimeGap)timeGap {
    _timeGap = timeGap;
    
    NSUInteger secondGap = (NSUInteger)timeGap;
    if (secondGap > 0) {
        self.timeCount = (24 * 60 * 60) / secondGap;
        //计算当前刻度间距下最大的偏移量
        self.contentWidth = self.hGap * self.timeCount;
    } else {
        NSLog(@"%s,(%d)\n-------该时间间隔无效---------", __func__, __LINE__);
    }
}

@end
