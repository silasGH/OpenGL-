//
//  ViewController.m
//  TimeRuler
//
//  Created by iBahs on 17/4/5.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import "ViewController.h"

#import "SGTimeRulerView.h"

@interface ViewController ()
<
    UITextFieldDelegate
>

@property (weak, nonatomic) IBOutlet UITextField *tf;
@property (nonatomic, weak) SGTimeRulerView *timeRulerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[self timeRulerView] setupTime:@"23:00:02"];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self.timeRulerView setupTime:textField.text];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self.timeRulerView setupTime:textField.text];
    return YES;
}

#pragma mark - setter and getter
- (SGTimeRulerView *)timeRulerView {
    if (_timeRulerView == nil) {
        CGFloat w = self.view.bounds.size.width;
        SGTimeRulerView *timeRuler = [[SGTimeRulerView alloc] initWithFrame:CGRectMake(0, 120, w, 100)];
        [self.view addSubview:timeRuler];
        _timeRulerView = timeRuler;
    }
    return _timeRulerView;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
